<template>
  <footer class="footer">
    <div class="footer__wrap">
      <div class="footer__secondary">
        <div class="footer__inner">
          <div class="footer__secondary__nav">
            <span><a href="https://www.imooc.com/u/1343480" target="_blank">河畔一角主页</a>|<a href="https://coding.imooc.com/class/113.html" target="_blank">Vue全栈打造商城</a>|<a href="https://coding.imooc.com/class/236.html" target="_blank">React全家桶打造通用后台</a>|<a href="https://coding.imooc.com/class/343.html" target="_blank">微信支付专项(H5/小程序/小程序云+Node+Mongo)</a></span>
            <p>
              <a href="https://www.cnblogs.com/jacksoft/">关于我们</a>|
              <a href="#">条款和条件</a>|
              <a href="#">隐私政策</a>
            </p>
            <p>Copyright © 2019 河畔一角 版权所有</p>
          </div>
        </div>
      </div>
    </div>
  </footer>
</template>
<script>
  export default{
    name:'NavFooter'
  }
</script>